const express = require('express');
const axios = require('axios');
const app = express();
const port = 3000;

// Serve static files from the public directory
app.use(express.static('public'));

// Weather API endpoint
app.get('/weather', async (req, res) => {
  const city = req.query.city;
  const apiKey = 'your_openweathermap_api_key';

  try {
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${apiKey}`);
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'An error occurred' });
  }
});

app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
