# Weather Web Application

This is a basic web application that fetches and displays weather data using Node.js, Express, and the OpenWeatherMap API.


## Getting Started

Follow these instructions to set up and run the system locally.


### Prerequisites

- Node.js: Make sure you have Node.js installed on your machine. You can download it from [nodejs.org](https://nodejs.org/).


### Installation

1. Extract the zip file to a directory of your choice.

2. Navigate to the project directory in your terminal:

   cd basic-web-app

3. Install the project dependencies:

   npm install


### Register for OpenWeatherMap API Key

1. Go to the [OpenWeatherMap website](https://home.openweathermap.org/users/sign_up) and sign up for a new account.

2. Once you're signed up and logged in, go to your [API keys page](https://home.openweathermap.org/api_keys) to create a new API key.

3. Copy the generated API key. You'll need this key to access the OpenWeatherMap API.


### Configuration

1. In the `app.js` file, replace `'your_openweathermap_api_key'` with the API key you obtained from OpenWeatherMap.


### Running the Application

1. Start the server by running the following command in the terminal:

   node app.js

2. Open your web browser and navigate to `http://localhost:3000`.

3. Enter a city name in the input field and press Enter or click the "Search" button to fetch and display weather information.


### Usage

- Enter the name of a city in the provided input field and press Enter or click the "Search" button to fetch and display weather information for that city.


### Troubleshooting

- If you encounter issues related to fetching data or incorrect weather information, ensure that you've configured the API key correctly and that the OpenWeatherMap API is functioning properly.

NOTE: After logging in to OpenWeatherMap and acquiring the API key, do not close the website. Leave it open. It may take some time before a result is displayed.